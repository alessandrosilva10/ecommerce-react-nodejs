# reactstrap-basic-sidebar
Static collapsible Bootstrap sidebar menu

# Installation
```
npm install
```
# run
```
npm start
```
# Preview
<a><img src="/preview.gif"></img></a>

# Original HTML/Bootstrap template

<a href="https://bootstrapious.com/p/bootstrap-sidebar">bootstrapious.com</a>
